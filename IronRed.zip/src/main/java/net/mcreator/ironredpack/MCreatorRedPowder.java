package net.mcreator.ironredpack;

import net.minecraft.item.ItemStack;

@Elementsironredpack.ModElement.Tag
public class MCreatorRedPowder extends Elementsironredpack.ModElement {
	public MCreatorRedPowder(Elementsironredpack instance) {
		super(instance, 6);
	}

	@Override
	public int addFuel(ItemStack fuel) {
		if (fuel.getItem() == new ItemStack(MCreatorRedPowderz.block, (int) (1)).getItem())
			return 2500;
		return 0;
	}
}
