package net.mcreator.ironredpack;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

@Elementsironredpack.ModElement.Tag
public class MCreatorIngots extends Elementsironredpack.ModElement {
	public MCreatorIngots(Elementsironredpack instance) {
		super(instance, 5);
	}
	public static CreativeTabs tab = new CreativeTabs("tabingots") {
		@SideOnly(Side.CLIENT)
		@Override
		public ItemStack getTabIconItem() {
			return new ItemStack(MCreatorRedIron.block, (int) (1));
		}

		@SideOnly(Side.CLIENT)
		public boolean hasSearchBar() {
			return true;
		}
	}.setBackgroundImageName("item_search.png");
}
